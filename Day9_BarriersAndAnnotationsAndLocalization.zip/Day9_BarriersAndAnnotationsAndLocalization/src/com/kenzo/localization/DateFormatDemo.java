package com.kenzo.localization;

import java.text.DateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;

public class DateFormatDemo {

	public static void main(String[] args) {
		
		//Locale locale=Locale.getDefault();
		
		//System.out.println(locale);  // en_US:  en: Language, US: Region
		
		//DateFormat dateFormat=DateFormat.getDateInstance();  //DateFormat.DEFAULT
		//DateFormat dateFormat=DateFormat.getDateInstance(DateFormat.FULL);
		//DateFormat dateFormat=DateFormat.getDateInstance(DateFormat.SHORT);
		//DateFormat dateFormat=DateFormat.getDateInstance(DateFormat.DEFAULT,Locale.CANADA);
		
		//Locale locale=new Locale("jp");
		//Locale locale=new Locale("en","IN");
		//Locale locale=new Locale("zh","CN");
		Locale locale=new Locale("en", "US","WIN");
		//DateFormat dateFormat=DateFormat.getDateInstance(DateFormat.FULL,locale);
		DateFormat dateFormat=DateFormat.getDateInstance(DateFormat.SHORT,locale);
		
		System.out.println(dateFormat.format(new Date()));
		
	}

}
