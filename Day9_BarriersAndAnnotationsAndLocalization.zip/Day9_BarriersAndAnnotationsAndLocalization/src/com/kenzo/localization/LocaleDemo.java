package com.kenzo.localization;

import java.util.Locale;

public class LocaleDemo {

	public static void main(String[] args) {
		
		Locale locale=new Locale.Builder().setLanguage("fr").setRegion("FR").build();
		
		System.out.println("Country: "+locale.getCountry());
		System.out.println("Display Country: "+locale.getDisplayCountry());
		System.out.println("Display Name: "+locale.getDisplayName());
		System.out.println("Language: "+locale.getLanguage());
		System.out.println("Display Language: "+locale.getDisplayLanguage());
		System.out.println("ISO3 Language: "+locale.getISO3Language());
		
		Locale[] locales= Locale.getAvailableLocales();
		
		for(Locale l:locales) {
			System.out.println(l);
		}
	}
}
