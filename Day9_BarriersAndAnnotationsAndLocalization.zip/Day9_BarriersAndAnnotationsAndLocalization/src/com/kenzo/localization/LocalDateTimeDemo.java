package com.kenzo.localization;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class LocalDateTimeDemo {

	public static void main(String[] args) {
		
		//LocalDate localDate=LocalDate.now();
		LocalDate localDate=LocalDate.of(2022, 04, 13);
		
		//LocalTime localTime=LocalTime.now();
		LocalTime localTime=LocalTime.of(12, 12, 12);
		
		LocalDateTime localDateTime=LocalDateTime.now();
		
		System.out.println(localDateTime);
		System.out.println(localDate.getDayOfMonth());
		System.out.println(localDate.getDayOfYear());
		System.out.println(localDate.getYear());
		System.out.println(localTime.getHour());
		
		
		LocalDate date=localDateTime.toLocalDate();
		LocalTime time=localDateTime.toLocalTime();
		
		

	}

}
