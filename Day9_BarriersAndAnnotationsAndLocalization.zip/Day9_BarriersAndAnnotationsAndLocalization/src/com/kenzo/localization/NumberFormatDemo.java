package com.kenzo.localization;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class NumberFormatDemo {

	public static void main(String[] args) {
		
//		NumberFormat numberFormat=NumberFormat.getNumberInstance();
//		double amount=123456.789;
//		System.out.println(numberFormat.format(amount));
		
//		NumberFormat numberFormat=NumberFormat.getNumberInstance(Locale.GERMANY);
//		double amount=123456.789;
//		System.out.println(numberFormat.format(amount));
		
//		Locale locale=new Locale("en", "IN");
//		NumberFormat numberFormat=NumberFormat.getNumberInstance(locale);
//		double amount=123456.789;
//		System.out.println(numberFormat.format(amount));
		
		//NumberFormat numberFormat=NumberFormat.getCurrencyInstance(Locale.CHINA);
//		Locale locale=new Locale("en","IN");
//		NumberFormat numberFormat=NumberFormat.getCurrencyInstance(locale);
//		System.out.println(numberFormat.format(1250));
//		

//		Locale locale=new Locale("en","IN");
//		NumberFormat numberFormat=NumberFormat.getPercentInstance(Locale.FRANCE);
//		System.out.println(numberFormat.format(0.5));
		
		
		String pattern="000.##";
		//DecimalFormat decimalFormat =new DecimalFormat();
		DecimalFormat decimalFormat =new DecimalFormat(pattern);
		System.out.println(decimalFormat.format(24.5734));
		
	}
}
