package com.kenzo.barrier;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

class FriendThread extends Thread {
	private int timeTaken;
	CyclicBarrier barrier;
	
	public FriendThread(int timeTaken, String name, CyclicBarrier barrier) {
		super(name);
		this.timeTaken = timeTaken;
		this.barrier = barrier;
	}
	
	public void run() {
		try {
			Thread.sleep(timeTaken);
			System.out.println(Thread.currentThread().getName() + " arrived!");
			int countArrived = barrier.await();
			if(countArrived == 0)
				System.out.println("All of us reached!");
		} catch (InterruptedException | BrokenBarrierException e) {
			e.printStackTrace();
		}
	}

}

public class CyclicBarrierDemo {

	public static void main(String[] args) {
		
		CyclicBarrier barrier = new CyclicBarrier(4);
		
		FriendThread friend1 = new FriendThread(1000, "Raghav", barrier);
		FriendThread friend2 = new FriendThread(2000, "Anshul", barrier);
		FriendThread friend3 = new FriendThread(3000, "Anand", barrier);
		FriendThread friend4 = new FriendThread(4000, "Ujjawal", barrier);
		
		FriendThread friend5 = new FriendThread(5000, "Mounika", barrier);
		FriendThread friend6 = new FriendThread(6000, "Preksha", barrier);
		FriendThread friend7 = new FriendThread(7000, "Diksha", barrier);
		FriendThread friend8 = new FriendThread(8000, "Shalini", barrier);
		
		friend1.start();
		friend2.start();
		friend3.start();
		friend4.start();
		
		friend5.start();
		friend6.start();
		friend7.start();
		friend8.start();
		
	}
}
