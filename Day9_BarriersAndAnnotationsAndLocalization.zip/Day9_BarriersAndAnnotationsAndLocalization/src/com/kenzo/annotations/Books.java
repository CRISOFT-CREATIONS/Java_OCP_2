package com.kenzo.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target(value = {ElementType.TYPE,ElementType.FIELD,
        ElementType.METHOD,ElementType.LOCAL_VARIABLE})
public @interface Books {
	Book[] value();
}
