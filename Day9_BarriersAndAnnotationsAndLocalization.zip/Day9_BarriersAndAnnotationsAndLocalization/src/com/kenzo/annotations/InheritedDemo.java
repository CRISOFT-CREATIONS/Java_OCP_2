package com.kenzo.annotations;

public class InheritedDemo {

	public static void main(String[] args) {
		Parent1 parent=new Parent1();
		
		Test test= parent.getClass().getAnnotation(Test.class);
		System.out.println(test.testDate());
		
		Child1 child1=new Child1();
		Test t1= child1.getClass().getAnnotation(Test.class);
		System.out.println(t1.testDate());
	}
}
@Test(testDate = "2022/04/13")
class Parent1{}

class Child1 extends Parent1{}
