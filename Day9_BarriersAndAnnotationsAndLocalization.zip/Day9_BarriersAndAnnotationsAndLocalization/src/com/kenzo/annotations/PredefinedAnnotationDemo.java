package com.kenzo.annotations;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JSpinner.DateEditor;

public class PredefinedAnnotationDemo {

	public static void main(String[] args) {
	}
}
class SafeVarArgsDemo{
	// final methods, static methods,constructors(Java 7)
	// private non static methods (Java9)
	
	@SafeVarargs
	private void viewAll(List<String>...lists) {
		
	}
	
	@SafeVarargs
	public SafeVarArgsDemo(List<String>...lists) {
		// TODO Auto-generated constructor stub
	}
	@SafeVarargs
	public final void finalMethod(List<String>...lists) {
		
	}
	public void test() {
		viewAll(new ArrayList<String>());
	}
}












class Parent{
	
	//@SuppressWarnings("rawtypes")
	//@SuppressWarnings("unchecked")
	//@SuppressWarnings(value = {"rawtypes","unchecked","unused"})
	//@SuppressWarnings("all")
	//@SuppressWarnings("abc")
	void test(List list) {
		list.add("John");
		
		int a;
		
		//@SuppressWarnings(value="removal")
		Integer i=new Integer(10);
		
		//@SuppressWarnings("deprecation")
		
		Date date=new Date(2003,10,12);
	}
	//@Deprecated(since = "2022",forRemoval = true)
	@Deprecated
	void testing() {
		
	}
	void testing(String name) {
		
	}
	
	//@SafeVarargs
	final int[] method2(int... is) {
		return is;
	}
}

class Child extends Parent{
	//String[] arrStr();
	
	//@Override
	public void tast() {
		super.testing("");
	}
}

//@FunctionalInterface
interface Sample{
	public void method();
	public void method1();
}