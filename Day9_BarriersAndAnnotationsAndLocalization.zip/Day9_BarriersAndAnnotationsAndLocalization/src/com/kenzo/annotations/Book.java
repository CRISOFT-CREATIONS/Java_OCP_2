package com.kenzo.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Target;

//@Target(ElementType.TYPE)
@Target(value = {ElementType.TYPE,ElementType.FIELD,
		          ElementType.METHOD,ElementType.LOCAL_VARIABLE})
@Repeatable(Books.class)
public @interface Book {
	String value() default "";
	//double price() default 10.0;
	int noOfPages();
	String[] authorNames();
	//String[][] abc();  2D array field not allowed
	//List list();       Object types not allowed
}


