package com.kenzo.annotations;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Scanner;

class Sample1{
	int val;
	
	public Sample1() {}
	public Sample1(int val) {
		this.val=val;
	}
	
	@Test(testDate = "2022/04/13")
	public int getVal() {
		return val;
	}
}
public class ReflectionDemo {
	public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, SecurityException {
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter fully qualified class name: ");
			String className=sc.nextLine();
			
			Class clazz=Class.forName(className);

			Method[] methods= clazz.getMethods();
			
			//System.out.println(Arrays.toString(methods));
			 for(Method m:methods) {
				System.out.println(m);
			}
			
			Constructor[] constructors=clazz.getConstructors();
			
			for(Constructor c:constructors) {
				System.out.println(c);
			}
			
			// fetching annotations info at runtime
			System.out.println("Enter method name:");
			String methodName=sc.nextLine();
			Method m= clazz.getMethod(methodName);
			Test t= m.getAnnotation(Test.class);
			System.out.println(t.testDate());
	}

}










