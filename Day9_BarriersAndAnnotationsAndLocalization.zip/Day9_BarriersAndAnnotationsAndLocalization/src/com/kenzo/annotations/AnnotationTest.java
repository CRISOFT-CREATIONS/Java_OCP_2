package com.kenzo.annotations;

import java.util.function.Function;

//@Book(price = 1000,value = "Java Book",noOfPages = 400)
public class AnnotationTest {
	//@Book(price = 2000,noOfPages = 200)
	int num;

	//@Book(price = 3000)
	//@Book(noOfPages = 30)
	//@Book("Java OCP")
	//@Book(value="Java OCP",noOfPages=50)
	//@Book(noOfPages = 300,authorNames = {"John","Mary"})
	//@Book(noOfPages = 300,authorNames = {"John","Mary"})
	//@Books(@Book(noOfPages = 300,authorNames = {"John","Mary"}))
	@Books({@Book(noOfPages = 300,authorNames = {"John","Mary"}),
		   @Book(noOfPages = 200,authorNames = {"Bob","Wiley"})})
	@Book(noOfPages = 200,authorNames = {"Bob","Wiley"})
	//@Book(noOfPages = 200,authorNames = {"Bob","Wiley"})
	public static void main(String[] args) {
		@Book(noOfPages = 200,authorNames = {"Bob","Wiley"})
		int val;
		
		//Number num= new @Test Double(10);
		
		//Function<String, String> func = ( @Test String x)->x.toUpperCase();
		
		String str="";
		
		//var myString = (@Test String)  str;
		
	}
}
