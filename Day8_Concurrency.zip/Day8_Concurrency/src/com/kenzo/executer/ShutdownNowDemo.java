package com.kenzo.executer;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ShutdownNowDemo {

	public static void main(String[] args) throws InterruptedException {
		
		ExecutorService service = Executors.newSingleThreadExecutor();
		
		long startTime = System.currentTimeMillis();
		service.submit(() -> {
			while(true) {
				if(Thread.currentThread().isInterrupted()) {
					System.out.println("Thread Interrupted");
					break;
				} else {
					System.out.println(System.currentTimeMillis()-startTime);
				}
			}
		});

//		service.shutdownNow();														// Simple shut it down!
		service.shutdown();
		
		if(service.awaitTermination(5, TimeUnit.SECONDS)) {
			System.out.println("Waited after 5 seconds!");
//			System.exit(0);
		}
		
		System.out.println("Exiting Normally!");
	}
}
