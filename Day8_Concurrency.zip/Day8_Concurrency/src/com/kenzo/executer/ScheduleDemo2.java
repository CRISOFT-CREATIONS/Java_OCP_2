package com.kenzo.executer;

import java.time.LocalDateTime;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ScheduleDemo2 {

	public static void main(String[] args) {
		
		ScheduledExecutorService service = Executors.newScheduledThreadPool(15);
		
//		service.scheduleWithFixedDelay(() ->System.out.println(new Random().nextInt(100)), 3, 5, TimeUnit.SECONDS);
//		try {
//			service.awaitTermination(10, TimeUnit.SECONDS);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		} finally {
//			System.out.println("Time UP!");
//			service.shutdown();
//		}
		
		service.scheduleAtFixedRate(() ->System.out.println(new Random().nextInt(100) + " " +LocalDateTime.now()), 3, 5, TimeUnit.SECONDS);
		try {
			service.awaitTermination(10, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Time UP!");
			service.shutdown();
		}
	}
}
