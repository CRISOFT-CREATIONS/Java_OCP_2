package com.kenzo.executer;

import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class RunThread implements Runnable {

	@Override
	public void run() {
		System.out.println("Run Thread : " +Thread.currentThread().getId());
	}
	
}

class CallThread implements Callable<Integer> {

	@Override
	public Integer call() throws Exception {
		
		return new Random().nextInt();
	}
	
}

public class ExecuterDemo {

	public static void main(String[] args) throws Exception {
		/*
		// create single one thread
		Executor executor = Executors.newSingleThreadExecutor();
		executor.execute(() -> System.out.println("Thread ID : " +Thread.currentThread().getId()));
		
		// Sub Interfaces : ExecuterService, ScheduledExecuterService
		executor.execute(new RunThread());
		*/
		
//		ExecutorService executorService = Executors.newFixedThreadPool(5);
//		executorService.submit(new RunThread());
		
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
//
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
		
		// No matter how many times we will run, it will only utilize 5 threads as we have mentioned in the thread pool!
		// i.e. Only 5 unique thread IDs
		
//		ExecutorService executorService = Executors.newCachedThreadPool();
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
//		executorService.submit(() -> System.out.println("Runnable Thread : " +Thread.currentThread().getId() + " is running!"));
	
		ExecutorService executorService = Executors.newSingleThreadExecutor();
//		Future<Integer> future = executorService.submit(new CallThread());
//		System.out.println(future.get());
//		executorService.shutdown();
		
		Future<?> unknownFuture = executorService.submit(() -> System.out.println("My Runnable task."));
		System.out.println(unknownFuture.get());				// null, because Future doesnt return in Runnable!
		
		
	}
}
