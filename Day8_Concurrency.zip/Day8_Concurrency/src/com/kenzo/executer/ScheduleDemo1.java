package com.kenzo.executer;

import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class ScheduleDemo1 {

	public static void main(String[] args) {
		// Executor : execute(Runnable)
		// ExecutorService : submit(Runnable), submit(Callable)
		
		ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
	
		ScheduledFuture<Integer> result = service.schedule(() -> {
			return new Random().nextInt(100);
		}, 3000, TimeUnit.MILLISECONDS);
		
		try {
			System.out.println(result.get(4, TimeUnit.SECONDS));
			System.out.println("Thank You for the result!");
		} catch (InterruptedException | ExecutionException | TimeoutException e) {
			System.out.println("Timeout, I don't need your result!");
//			e.printStackTrace();
		} finally {
			System.out.println("isDone? " +result.isDone());					// false because the task abruptly terminated
			System.out.println("isCancelled? " +result.isCancelled());
			service.shutdown();
		}
	}
}
