package com.kenzo.executer;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class SubmitFutureDemo {

	public static void main(String[] args) throws Exception {
		
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		
		long startTime = System.currentTimeMillis();
		
		Future<Integer> result = executorService.submit(() -> {
			Thread.sleep(500);					// 10000, gives cancelled!
			return new Random().nextInt();
		});
		
		long totalTime =0;
		while(!result.isDone()) {	// completed normally, terminated due to exception or got cancelled by the user.
			totalTime = System.currentTimeMillis()-startTime;
			System.out.println(totalTime);
			if(totalTime > 3000)
				result.cancel(true);
		}
		if(result.isDone())
			if(result.isCancelled())
				System.out.println("Task was cancelled!");
			else
				System.out.println("Task completed normally! : " +result.get());
		
		executorService.shutdown();
	}
}
