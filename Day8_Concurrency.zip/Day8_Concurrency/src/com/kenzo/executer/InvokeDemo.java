package com.kenzo.executer;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class InvokeDemo {

	public static void main(String[] args) throws Exception {
		
		ExecutorService executorService = Executors.newFixedThreadPool(5);
		
		List<Callable<Integer>> callables = new ArrayList<Callable<Integer>>();
		Callable<Integer> callable1 = () -> {return 1;};
		Callable<Integer> callable2 = () -> 2;
		
		callables.add(callable1);
		callables.add(callable2);
		callables.add(() -> 4);
		callables.add(() -> 3);
		callables.add(() -> 5);
		callables.add(() -> 6);
		callables.add(() -> new Random().nextInt());
		callables.add(() -> new Random().nextInt());
		
//		List<Future<Integer>> results = executorService.invokeAll(callables);
//		
//		for(Future<Integer> result:results) {
//			System.out.println(result.get());
//		}
		
		Integer result = executorService.invokeAny(callables);
		System.out.println(result);
		
		executorService.shutdown();
	}
}
