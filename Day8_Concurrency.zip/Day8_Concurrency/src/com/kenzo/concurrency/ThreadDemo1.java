package com.kenzo.concurrency;

//Implementation of Runnable: Way 1
class RunnableThread implements Runnable {

	@Override
	public void run() {
		System.out.println("Thread ID : " +Thread.currentThread().getId() + " is running!");
	}
	
}

class MyThread extends Thread {
	
	public void run() { 
		System.out.println("Thread ID : " +Thread.currentThread().getId() + " is running!");
	}
}

public class ThreadDemo1 {

	public static void main(String[] args) {
		
		System.out.println("Thread ID : " +Thread.currentThread().getId() + " \nThread Name : " +Thread.currentThread().getName());
//		System.out.println("Hello World.");
		
		//Implementation of Runnable: Way 2
		Runnable myRunnableThread = () -> {System.out.println("Thread ID : " +Thread.currentThread().getId() + " is running!");};
		Thread runThread = new Thread(myRunnableThread);
		
		//Implementation of Runnable: Way 3
		Thread runThread2 = new Thread(() -> System.out.println("Thread ID : " +Thread.currentThread().getId() + " is running!"));
		
		Thread thread1 = new Thread(new RunnableThread());
		Thread thread2 = new Thread(new RunnableThread());
		Thread thread3 = new Thread(new RunnableThread());
		
		MyThread myThread1 = new MyThread();
		MyThread myThread2 = new MyThread();
		MyThread myThread3 = new MyThread();
		
		runThread.start();
		runThread2.start();
		
		thread1.start();
		thread2.start();
		thread3.start();
		
		myThread1.start();
		myThread2.start();
		myThread3.start();
	}
}
