package com.kenzo.concurrency;

class Task1 implements Runnable {

	@Override
	public void run() {
		for(int i=0; i<10; i++) {
			System.out.println(i + ": " +Thread.currentThread().getId());
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
				Thread.currentThread().interrupt();
				break;
			}
		}
	}
	
}

public class ThreadDemo2 {

	public static void main(String[] args) {
		
		Thread thread = new Thread(new Task1());
		Thread thread2 = new Thread(new Task1());
		
		thread.start();
		thread2.start();
		
		thread.interrupt();
	}
}
