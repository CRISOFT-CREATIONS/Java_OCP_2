package com.kenzo.threadSync;

public class ThreadSyncEx {

	public static void main(String[] args) throws InterruptedException {
		
		CounterTest counterTest = new CounterTest();
		Thread thread1 = new Thread(counterTest);
		Thread thread2 = new Thread(counterTest);
		thread1.start();
		thread2.start();
		thread1.join();
		thread2.join();
		System.out.println(counterTest.getCounter());
	}
}

class CounterTest implements Runnable {

	private int counter;
	
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getId());
		for(int i=1; i<=2000; i++)
			increment();
	}

//	public synchronized void increment() {
//		System.out.println(Thread.currentThread().getId() + " started.");
//		counter++;														// not an atomic operation: Load counter variable in memory
//		System.out.println(Thread.currentThread().getId() + " completed.");		
//	}

	public void increment() {
		System.out.println(Thread.currentThread().getId() + " started.");
		synchronized (this) {											// synchronized block
			counter++;			
		}					
		System.out.println(Thread.currentThread().getId() + " completed.");		
	}
	
	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}
}