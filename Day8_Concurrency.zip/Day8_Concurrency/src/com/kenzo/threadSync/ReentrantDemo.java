package com.kenzo.threadSync;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

class Table1{
	private static final ReentrantLock lock=new ReentrantLock();
	static long currentThread;
	public static void printTable(int n) throws InterruptedException {
		currentThread=Thread.currentThread().getId();
		System.out.println(currentThread+" acquired the lock.");
//		lock.lock();			// trying lock once
//		lock.tryLock();			// trying lock indefinitely
		lock.tryLock(2, TimeUnit.SECONDS);		// trying lock in 2 secs
		try {
			for(int i=1;i<=10;i++) {
				if(i==5 && currentThread==15) 
					throw new NullPointerException();
				System.out.println(n+" * "+i+" = "+(n*i));
			}
		}catch (Exception e) {
			System.out.println("Exception occurred. in "+currentThread);
		}finally {
			System.out.println(currentThread+" releasing lock");
			lock.unlock();	
		}
	}
}
public class ReentrantDemo {
	public static void main(String[] args) {
		Thread th1=new Thread() {
			public void run() {
				try {
					Table1.printTable(1);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		
		Thread th2=new Thread() {
			public void run() {
				Table.printTable(10);
			}
		};
		
		Thread th3=new Thread() {
			public void run() {
				Table.printTable(20);
			}
		};
		
		th1.start();
		th2.start();
		th3.start();

	}

}
