package com.kenzo.threadSync;

import java.util.concurrent.locks.ReentrantLock;

class Table{
	//static Object lock=new Object();
	private static final ReentrantLock lock=new ReentrantLock();
	
	public static void printTable(int n) {
		
		//synchronized (Table.class) {
		//synchronized(lock) {
		lock.lock();
		try {
			for(int i=1;i<=10;i++) {
				if(i==5 && Thread.currentThread().getId()==15) 
					throw new NullPointerException();
				System.out.println(n+" * "+i+" = "+(n*i));
			}
		}catch (Exception e) {
			System.out.println("Exception occurred.");
		}finally {
			lock.unlock();	
		}
		
		//}
		
	}
}
public class SynchronizationDemo3 {

	public static void main(String[] args) {
		Thread th1=new Thread() {
			public void run() {
				Table.printTable(1);
			}
		};
		
		Thread th2=new Thread() {
			public void run() {
				Table.printTable(10);
			}
		};
		
		Thread th3=new Thread() {
			public void run() {
				Table.printTable(20);
			}
		};
		
		th1.start();
		th2.start();
		th3.start();

	}

}
