package com.kenzo.threadSync;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;

public class BlockingQueueDemo {

	public static void main(String[] args) {
		
		Queue<Integer> queue = new LinkedBlockingDeque<Integer>();
		
		queue.offer(23);
		queue.offer(54);
		queue.offer(47);
		
		System.out.println(queue.peek());							// reads head
		System.out.println(queue.poll());							// reads head and remove
		System.out.println(queue);
	
		BlockingQueue<Integer> arrQueue = new ArrayBlockingQueue<Integer>(10);
		
		try {
			arrQueue.offer(10,10,TimeUnit.SECONDS);
			arrQueue.poll(5, TimeUnit.SECONDS);										// reads head and remove
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println(arrQueue);
		
		Deque<Integer> deque = new ArrayDeque<Integer>();
		
		deque.offerFirst(10);			// 10
		deque.offer(21);				// 10 21
		deque.offerFirst(23);			// 23 10 21
		deque.offerLast(74);			// 23 10 21 74
		deque.offer(66);				// 23 10 21 74 66
		
		System.out.println(deque);
		
		System.out.println("-------------------------");
		
		deque.push(3);
		System.out.println(deque);
		
		System.out.println("-------------------------");
		
		deque.pop();
		System.out.println(deque);
		
		System.out.println("-------------------------");
		
		
	}
}
