package com.kenzo.threadSync;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class SyncMethodDemo {

	public static void main(String[] args) {
		
		List<Integer> list = new ArrayList<Integer>();
		
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(50);
		
		System.out.println("list: " +list);
		
		List<Integer> syncList = Collections.synchronizedList(list);
		
		syncList.add(60);
		syncList.add(40);
		
		System.out.println("syncList: " +syncList);
		
//		for(Integer i:syncList) {
//			if(i == 50)
//				syncList.remove(i);
//		}
		
		Iterator<Integer> items = syncList.iterator();
		
		while(items.hasNext()) {
			if(items.next() == 30) {
				items.remove();
			}
		}
		
		System.out.println(syncList);
	}
}
