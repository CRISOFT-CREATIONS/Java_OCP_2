package com.kenzo.threadSync;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

public class CopyOnWriteArrayListEx {

	public static void main(String[] args) {
		List<String> names = new CopyOnWriteArrayList<String>();
//		List<String> names = new ArrayList<String>();
		
		names.add("Mark");
		names.add("Robin");
		names.add("Josh");
		
		for(String name:names) {
			if(!names.contains("Alice")) {			
				names.add("Alice");										// ConcurrentModificationException when using ArrayList
			}
		}
		System.out.println(names);
		
		Set<Integer> nums = new CopyOnWriteArraySet<Integer>();
		
		nums.add(1);
		nums.add(2);
		nums.add(3);
		
		
	}
}
