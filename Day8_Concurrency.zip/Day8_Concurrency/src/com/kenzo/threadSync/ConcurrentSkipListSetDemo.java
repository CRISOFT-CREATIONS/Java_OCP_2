package com.kenzo.threadSync;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;

public class ConcurrentSkipListSetDemo {

	public static void main(String[] args) {
		
		Set<Integer> nums = new ConcurrentSkipListSet<Integer>();
		
		nums.add(40);
		nums.add(20);
		nums.add(10);
		nums.add(30);
		
		System.out.println(nums);
		System.out.println("-------------------------");
		Iterator<Integer> items = nums.iterator();
		while(items.hasNext()) {
			int val = items.next();
			System.out.println(val);
			if(val == 30)
				items.remove();
		}
		System.out.println("-------------------------");
		System.out.println(nums);
	}
}
