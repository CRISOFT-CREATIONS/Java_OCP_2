package com.kenzo.threadSync;

import java.util.HashMap;

public class ConcurrentCollectionDemo {

	public static void main(String[] args) {
		
		HashMap<Integer, String> students = new HashMap<Integer, String>();
		
		students.put(1001, "John");
		students.put(1002, "Neil");
		students.put(1003, "David");
		students.put(1004, "Kevin");
		students.put(1005, "Stacy");
		
		for(Integer key: students.keySet()) {
			students.put(1006, "Jane");
			if(key == 1003)
//				students.remove(key);								// gives an exception, ConcurrentModificationException, writing during reading
				System.out.println(students.remove(key));			// doesnt give an exception
//				students.replace(key, "Mark");						// doesnt give an exception
				
//			students.put(1006, "Jane");								// gives an exception
			
			System.out.println(key + " " + students.get(key));
		}
		
		System.out.println(students.putIfAbsent(1003, "Stacy"));
	}
}
