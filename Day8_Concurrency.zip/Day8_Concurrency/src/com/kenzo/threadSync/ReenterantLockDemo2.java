package com.kenzo.threadSync;

import java.util.concurrent.locks.ReentrantLock;

class Counter {
	private static int count;
	private static final ReentrantLock lock = new ReentrantLock(true);		// fairness policy : accepts a fairness parameter, 
																	// true - locks favor granting access to the lonmgest waiting thread
																	// false - lock doesnot guarantee the order of threads 
	
	public static void incr() {
		lock.lock();
		try {														// nested lock
			lock.lock();
			count++;
														// make sure, whenever we lock, we have to unlock!
		}
		finally {
			lock.unlock();
			lock.unlock();
		}
	}
}

public class ReenterantLockDemo2 {

	public static void main(String[] args) {
		Thread th1 = new Thread() {
			public void run() {
				System.out.println(Thread.currentThread().getId());
				Counter.incr();
			}
		};
		
		Thread th2 = new Thread() {
			public void run() {
				System.out.println(Thread.currentThread().getId());
				Counter.incr();
			}
		};
		
		th1.start();
		th2.start();
	}
}
